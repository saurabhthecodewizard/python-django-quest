import math

# print(help(math))


value = 4.35
print(math.floor(value))
print(math.ceil(value))
# Round to closest even number if in the middle
print(round(value))

print(math.log(math.e))

print(math.log(100, 10))  # 10 ** 2

print(math.sin(10))

math.degrees(math.pi/2)

print(math.radians(180))
